package com.sale.ecommerce.interfaces;

public interface IPessoa<T,N> extends IGenericOperations<T,N>{
}
