package com.sale.ecommerce.interfaces;

public interface IEndereco<T,N> extends IGenericOperations<T,N>{
}
