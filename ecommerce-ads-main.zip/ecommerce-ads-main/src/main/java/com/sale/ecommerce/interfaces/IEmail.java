package com.sale.ecommerce.interfaces;

public interface IEmail<T,N> extends IGenericOperations<T,N>{
}
