package com.sale.ecommerce.interfaces;

public interface IPessoaJuridica<T,N> extends IGenericOperations<T,N>{
}
