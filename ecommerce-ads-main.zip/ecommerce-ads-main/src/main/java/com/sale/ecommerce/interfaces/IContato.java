package com.sale.ecommerce.interfaces;

public interface IContato<T,N> extends IGenericOperations<T,N>{
}
