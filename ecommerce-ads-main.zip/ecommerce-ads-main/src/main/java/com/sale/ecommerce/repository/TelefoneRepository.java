package com.sale.ecommerce.repository;

import com.sale.ecommerce.model.Telefone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TelefoneRepository extends JpaRepository<Telefone,Integer> {
}
