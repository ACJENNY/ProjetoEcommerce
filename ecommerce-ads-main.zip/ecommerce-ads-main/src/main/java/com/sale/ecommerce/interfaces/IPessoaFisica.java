package com.sale.ecommerce.interfaces;

public interface IPessoaFisica<T,N> extends IGenericOperations<T,N>{
}
