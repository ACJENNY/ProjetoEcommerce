package com.sale.ecommerce.interfaces;

public interface ITelefone<T,N> extends IGenericOperations<T,N>{
}
